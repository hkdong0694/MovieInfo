package com.example.movieinfo_mvp;

public interface BasePresenter {

    void start();

}
