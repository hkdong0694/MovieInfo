package com.example.movieinfo_mvp;

public interface BaseView<T> {

    void setPresenter(T presenter);

}
