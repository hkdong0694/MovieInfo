package com.example.movieinfo_mvp.Contract;

import com.example.movieinfo_mvp.BasePresenter;
import com.example.movieinfo_mvp.BaseView;

public interface DailyMovieContract {

    interface View extends BaseView {


    }

    interface Presenter extends BasePresenter {


    }

}
