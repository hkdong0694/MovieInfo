package com.example.movieinfo_mvp.Presenter;

import com.example.movieinfo_mvp.Contract.DailyMovieContract;

public class DailyMoviePresenterimpl implements DailyMovieContract.Presenter {

    @Override
    public void start() {

    }
}
