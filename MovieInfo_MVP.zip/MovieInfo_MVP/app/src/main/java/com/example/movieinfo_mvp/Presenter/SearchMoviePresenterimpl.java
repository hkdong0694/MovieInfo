package com.example.movieinfo_mvp.Presenter;

import com.example.movieinfo_mvp.Contract.SearchMovieContract;

public class SearchMoviePresenterimpl implements SearchMovieContract.Presenter {

    @Override
    public void start() {

    }
}
