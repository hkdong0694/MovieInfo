package com.example.movieinfo_mvp.Presenter;

import com.example.movieinfo_mvp.Contract.TopMovieContract;

public class TopMoviePresenterimpl implements TopMovieContract.Presenter {

    @Override
    public void start() {



    }
}
